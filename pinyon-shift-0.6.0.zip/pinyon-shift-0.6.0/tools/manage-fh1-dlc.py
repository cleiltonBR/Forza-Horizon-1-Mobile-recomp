#!/usr/bin/env python3
"""Import verified owned FH1 content into the runtime's existing content tree."""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import uuid
import zipfile
from pathlib import Path, PurePosixPath, PureWindowsPath

ROOT = Path(__file__).resolve().parents[1]
CONTENT = Path("0000000000000000/4D5309C9")
PACKAGE_ID = re.compile(r"[0-9A-F]{1,42}\Z")
MAGIC = (b"LIVE", b"PIRS", b"CON ")
MAX_PACKAGE = 2 * 1024**3
RALLY = "6F6992766050D818245ADD408031E280FB5F4E634D"


def long_path(path: Path) -> Path:
    path = path.resolve()
    if os.name == "nt" and not str(path).startswith("\\\\?\\"):
        value = str(path)
        return Path("\\\\?\\UNC\\" + value[2:] if value.startswith("\\\\") else "\\\\?\\" + value)
    return path


def write_json(path: Path, value: object) -> None:
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def catalog() -> dict:
    return json.loads((ROOT / "config/supported-dlc.json").read_text(encoding="utf-8"))


def import_record(path: Path) -> dict | None:
    try:
        record = json.loads(path.read_text(encoding="utf-8"))
        if (isinstance(record, dict) and record.get("package_id") == path.stem and
                isinstance(record.get("display_name", path.stem), str) and
                all(isinstance(record[key], str) and re.fullmatch(r"[0-9A-F]{64}", record[key])
                    for key in ("sha256", "payload_sha256", "header_sha256") if key in record)):
            return record
    except (OSError, ValueError):
        pass
    return None


def package_paths(state: Path, package_id: str) -> tuple[Path, Path, Path]:
    if not PACKAGE_ID.fullmatch(package_id):
        raise ValueError("invalid package ID")
    title = state / "user" / CONTENT
    return (title / "00000002" / package_id,
            title / "Disabled" / "00000002" / package_id,
            title / "Headers" / "00000002" / (package_id + ".header"))


def payload_catalog(root: Path) -> tuple[list[dict], str]:
    files = []
    # The digest depends on the order. Sort as Windows paths compare
    # (case-insensitive, "\" separators) on every platform, the order the
    # catalog's payload_sha256 values were made with; POSIX Path sorting
    # is case-sensitive, so Rally failed to verify on macOS and Linux.
    for path in sorted(root.rglob("*"), key=lambda p: PureWindowsPath(p.relative_to(root))):
        if path.is_symlink():
            raise ValueError("content contains a symbolic link")
        if path.is_file():
            with path.open("rb") as stream:
                digest = hashlib.file_digest(stream, "sha256").hexdigest().upper()
            files.append(dict(path=path.relative_to(root).as_posix(),
                              size=path.stat().st_size, sha256=digest))
    digest = hashlib.sha256(json.dumps(files, sort_keys=True,
                                      separators=(",", ":")).encode()).hexdigest().upper()
    return files, digest


def inspect(stream, size: int, manifest: dict) -> tuple[dict, dict]:
    header = stream.read(0x971A)
    if len(header) != 0x971A or header[:4] not in MAGIC:
        raise ValueError("not an Xbox 360 content package")
    if header[0x360:0x364].hex().upper() != manifest["title_id"]:
        raise ValueError("package belongs to another game")
    if header[0x344:0x348].hex().upper() != manifest["content_type"]:
        raise ValueError("expected Marketplace DLC, not a title update or save")
    if not len(header) <= size <= MAX_PACKAGE:
        raise ValueError("invalid DLC package size")
    content_id = header[0x32C:0x340].hex().upper()
    package = next((p for p in manifest["packages"] if p["content_id"] == content_id), None)
    if package is None:
        raise ValueError("this DLC package is not in the verified catalog")
    digest = hashlib.sha256(header)
    total = len(header)
    while block := stream.read(4 * 1024**2):
        total += len(block)
        if total > size:
            raise ValueError("package size changed while reading")
        digest.update(block)
    if total != size:
        raise ValueError("incomplete DLC package")
    sha = digest.hexdigest().upper()
    for rejected in package["rejected"]:
        if rejected["sha256"] == sha:
            raise ValueError(f'{package["display_name"]}: {rejected["reason"]}')
    variant = next((v for v in package["accepted"] if v["size"] == size and v["sha256"] == sha), None)
    if variant is None:
        raise ValueError(f'{package["display_name"]}: SHA-256 differs from the verified inputs')
    return package, variant


def record_variants(package: dict, shas: list[str]) -> list[dict]:
    """Catalog variants for these hashes, in catalog order, or ValueError."""
    variants = [v for v in package["accepted"] if v["sha256"] in shas]
    if not shas or len(variants) != len(set(shas)):
        raise ValueError("import record is damaged; import the original package again")
    return variants


def combined_mask(variants: list[dict]) -> str:
    """Several verified variants of one package share a payload and differ
    only in the purchase recorded in their licence; owning each grants the
    union, as the original console would after both purchases."""
    mask = 0
    for variant in variants:
        mask |= int(variant["license_mask"], 16)
    return f"{mask:08X}"


def safe_archive_path(name: str) -> None:
    path = PurePosixPath(name.replace("\\", "/"))
    if path.is_absolute() or ".." in path.parts or ":" in name or "\0" in name:
        raise ValueError("unsafe ZIP member path")


NOT_FOUND = ("no FH1 DLC packages found; choose the original package files (no "
             "extension, starting with LIVE, CON or PIRS), a ZIP holding them, or "
             "Xenia's installed content folder for the game (4D5309C9, holding "
             "00000002 and Headers)")


def unpacked_variants(header: bytes, package: dict) -> list[dict]:
    """The catalog variants an installed package's header licenses, or
    ValueError. The header is the 328-byte content record the runtime and
    Xenia both keep, followed by the 4-byte licence mask."""
    name = package["display_name"]
    if (len(header) != 332 or header[4:8] != bytes.fromhex("00000002") or
            header[0x140:0x144] != bytes.fromhex("4D5309C9") or
            header[0x108:0x132].rstrip(b"\0").decode("ascii", "replace").upper()
            != package["package_id"]):
        raise ValueError(f"{name}: the installed package's header is not this package's; "
                         "import the original package instead")
    mask = int.from_bytes(header[328:332], "little")
    variants = [v for v in package["accepted"] if int(v["license_mask"], 16) == mask]
    if not variants and mask == int(combined_mask(package["accepted"]), 16):
        variants = list(package["accepted"])
    if not variants:
        raise ValueError(f"{name}: the installed package's licence does not match a verified "
                         "package; import the original package instead")
    return variants


def stage_unpacked(source: Path, manifest: dict) -> tuple[list[tuple], set[Path]]:
    """Packages already unpacked by Xenia's Install Content, laid out as
    <title>/00000002/<package id> with <title>/Headers/00000002/<id>.header,
    the layout this importer publishes. Verified by payload digest and the
    header's licence; the original package is not needed."""
    packages = {p["package_id"]: p for p in manifest["packages"]}
    folders = [source] + sorted(p for p in source.rglob("*") if p.is_dir() and not p.is_symlink())
    found, roots = [], set()
    for folder in folders:
        package = packages.get(folder.name.upper())
        if package is None or folder.parent.name != "00000002":
            continue
        roots.add(folder)
        header = folder.parent.parent / "Headers" / "00000002" / (folder.name + ".header")
        if not header.is_file():
            raise ValueError(f'{package["display_name"]}: {folder} is an unpacked package without '
                             f"its header ({header.parent}); choose Xenia's 4D5309C9 folder that "
                             "holds both 00000002 and Headers, or the original package file")
        variants = unpacked_variants(header.read_bytes(), package)
        found.append((None, package, variants[0], variants, (folder, header)))
    return found, roots


def stage_inputs(source: Path, temporary: Path, manifest: dict) -> list[tuple]:
    """Read only the inputs; never extract wrapper member paths to the host."""
    found = {}
    skipped = []

    def accept(stream, size: int) -> None:
        if size > MAX_PACKAGE:
            raise ValueError("DLC package exceeds the supported size")
        path = temporary / f"input-{len(found)}.stfs"
        with path.open("wb") as output:
            # Bound ZIP inflation even if its size fields are inconsistent.
            copied = 0
            while block := stream.read(4 * 1024**2):
                copied += len(block)
                if copied > size:
                    raise ValueError("package exceeds its declared size")
                output.write(block)
        with path.open("rb") as file:
            package, variant = inspect(file, size, manifest)
        id = package["package_id"]
        if id in found:
            # Same payload, another licence: keep one copy and both purchases.
            if all(v["sha256"] != variant["sha256"] for v in found[id][3]):
                found[id][3].append(variant)
            path.unlink()
            return
        found[id] = (path, package, variant, [variant], None)

    unpacked, unpacked_roots = stage_unpacked(source, manifest) if source.is_dir() else ([], set())
    inputs = sorted(source.rglob("*")) if source.is_dir() else [source]
    for path in inputs:
        if path.is_symlink():
            raise ValueError("input folder contains a symbolic link")
        if not path.is_file() or any(root in path.parents for root in unpacked_roots):
            continue
        with path.open("rb") as stream:
            magic = stream.read(4)
        if magic in MAGIC:
            with path.open("rb") as stream:
                accept(stream, path.stat().st_size)
        elif zipfile.is_zipfile(path):
            try:
                with zipfile.ZipFile(path) as archive:
                    for member in archive.infolist():
                        safe_archive_path(member.filename)
                        if member.is_dir():
                            continue
                        with archive.open(member) as stream:
                            prefix = stream.read(4)
                        if prefix in MAGIC:
                            with archive.open(member) as stream:
                                accept(stream, member.file_size)
            except (NotImplementedError, zipfile.BadZipFile, RuntimeError) as error:
                # A folder can hold game ZIPs that are not DLC wrappers, such
                # as an installed package's Media/DLCZips (an unsupported
                # compression method): skip them. A chosen ZIP must be read.
                # NotImplementedError is a RuntimeError; an encrypted member
                # raises the plain one.
                reason = ("it uses a compression method that can't be read here, such as "
                          "Deflate64; extract it first" if isinstance(error, NotImplementedError)
                          else "it is damaged" if isinstance(error, zipfile.BadZipFile)
                          else "it is encrypted")
                if not source.is_dir():
                    raise ValueError(f"the ZIP cannot be read: {reason}") from None
                skipped.append(f"{path.name} ({reason})")
        elif not source.is_dir():
            raise ValueError("choose a raw DLC package, DLC folder or ZIP")
    for entry in unpacked:
        id = entry[1]["package_id"]
        if id not in found:
            found[id] = entry
    if not found:
        raise ValueError(NOT_FOUND + ("" if not skipped else
                                      "; skipped: " + "; ".join(skipped[:5])))
    return list(found.values())


@contextlib.contextmanager
def mutation_lock(state: Path):
    metadata = state / "dlc"
    metadata.mkdir(parents=True, exist_ok=True)
    with (metadata / "import.lock").open("a+b") as lock:
        lock.seek(0)
        lock.write(b"\0")
        lock.flush()
        lock.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            if os.name == "nt":
                running = subprocess.check_output(
                    ["tasklist.exe", "/FI", "IMAGENAME eq pinyon_shift.exe", "/FO", "CSV", "/NH"],
                    creationflags=subprocess.CREATE_NO_WINDOW)
                if b'"pinyon_shift.exe"' in running.lower():
                    raise ValueError("close the game before changing DLC")
            elif shutil.which("pgrep") and not os.environ.get("PINYON_SHIFT_TEST_ALLOW_RUNNING_GAME"):
                # Linux and macOS: the game reads the content tree while it runs.
                if subprocess.call(["pgrep", "-x", "pinyon_shift"], stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL) == 0:
                    raise ValueError("close the game before changing DLC")
            yield
        finally:
            if os.name == "nt":
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)


def verified_content(state: Path, id: str, *, require_enabled: bool = False) -> tuple[Path, dict, dict]:
    """Validate the installed payload and original licence before using it."""
    state = long_path(state)
    active, inactive, header = package_paths(state, id)
    if active.exists() and inactive.exists():
        raise ValueError("both enabled and disabled copies exist")
    content = active if active.is_dir() else inactive
    if not content.is_dir() or not header.is_file():
        raise ValueError("import the verified package first")
    if require_enabled and content != active:
        raise ValueError("enable the imported package first")
    record = import_record(state / "dlc" / (id + ".json"))
    package = next((p for p in catalog()["packages"] if p["package_id"] == id), None)
    if not package or not record:
        raise ValueError("import record is damaged; import the original package again")
    shas = record.get("variants", [record.get("sha256")])
    if not isinstance(shas, list) or record.get("sha256") not in shas:
        raise ValueError("import record is damaged; import the original package again")
    mask = combined_mask(record_variants(package, shas))
    data = header.read_bytes()
    if (len(data) not in (328, 332) or
            record.get("header_sha256") != hashlib.sha256(data).hexdigest().upper() or
            record.get("license_mask") != mask or
            int.from_bytes(data[328:332], "little") != int(mask, 16)):
        raise ValueError("content header or licence changed; import the original package again")
    _, digest = payload_catalog(content)
    if digest != package["payload_sha256"] or record.get("payload_sha256") != digest:
        raise ValueError("installed content is incomplete or changed; import the original package again")
    return content, package, record


def list_content(state: Path) -> list[dict]:
    state = long_path(state)
    records = []
    metadata = state / "dlc"
    for path in sorted(metadata.glob("*.json")):
        id = path.stem
        if not PACKAGE_ID.fullmatch(id):
            continue
        enabled, disabled, header = package_paths(state, id)
        record = import_record(path)
        if record is None:
            records.append(dict(package_id=id, display_name=id, enabled=enabled.is_dir(),
                                status="metadata_invalid"))
            continue
        record["enabled"] = enabled.is_dir()
        record["status"] = ("conflict" if enabled.exists() and disabled.exists() else
                            "missing" if not (enabled.is_dir() or disabled.is_dir()) or not header.is_file()
                            else "gameplay_unverified")
        if header.is_file() and record.get("header_sha256") != hashlib.sha256(header.read_bytes()).hexdigest().upper():
            record["status"] = "missing"
        if id == RALLY:
            # Report generated assets separately from gameplay qualification.
            try:
                prepared = json.loads((state / "cache/rally_adapter/preparation.json").read_text())
                recipe = prepared["recipe"]
                record["rally_assets_cached"] = (prepared["schema"] == "pinyon-shift.rally-preparation.v1" and
                    recipe["package_sha256"] == record["sha256"] and
                    recipe["header_sha256"] == record["header_sha256"] and
                    (state / "cache/rally_adapter/game/media/db/gamedb.slt").is_file() and
                    (state / "cache/rally_adapter/rally-stage.toml").is_file() and
                    (state / "cache/rally_adapter/rally-pace.toml").is_file())
            except (OSError, ValueError, KeyError, TypeError):
                record["rally_assets_cached"] = False
        records.append(record)
    known = {r["package_id"] for r in records}
    for folder in (state / "user" / CONTENT / "00000002",
                   state / "user" / CONTENT / "Disabled" / "00000002"):
        if not folder.exists():
            continue
        for path in folder.iterdir():
            if path.is_dir() and path.name not in known:
                records.append(dict(package_id=path.name, display_name=path.name,
                                    enabled=folder.name == "00000002" and folder.parent.name == "4D5309C9",
                                    status="unmanaged"))
    return records


def import_content(source: Path, state: Path, extractor: Path) -> list[dict]:
    state = long_path(state)
    with mutation_lock(state), tempfile.TemporaryDirectory(prefix="staging-", dir=state / "dlc") as directory:
        staging = Path(directory)
        inputs = stage_inputs(source, staging, catalog())
        repair = set()
        # Licences already imported for each package; a new variant adds to them.
        previous = {}
        # Reject batch conflicts before publishing any package.
        for _, package, *_ in inputs:
            id = package["package_id"]
            enabled, disabled, _ = package_paths(state, id)
            record_path = state / "dlc" / (id + ".json")
            if enabled.exists() or disabled.exists():
                if enabled.exists() and disabled.exists():
                    raise ValueError(f'{package["display_name"]}: both enabled and disabled copies exist')
                if not record_path.is_file():
                    raise ValueError(f'{package["display_name"]}: existing unmanaged content; leave it in place')
                record = import_record(record_path)
                if record and record.get("sha256"):
                    try:
                        previous[id] = (record["sha256"], record_variants(
                            package, record.get("variants", [record["sha256"]])))
                    except ValueError:
                        pass
                _, digest = payload_catalog(enabled if enabled.exists() else disabled)
                if digest != package["payload_sha256"]:
                    repair.add(id)
        for index, (input_path, package, variant, variants, unpacked) in enumerate(inputs):
            id = package["package_id"]
            enabled, disabled, header = package_paths(state, id)
            record_path = state / "dlc" / (id + ".json")
            primary, owned = previous.get(id, (variant["sha256"], []))
            shas = {v["sha256"] for v in owned + variants}
            variants = [v for v in package["accepted"] if v["sha256"] in shas]
            mask = combined_mask(variants)
            installed = enabled if enabled.exists() else disabled
            if id not in repair and installed.exists() and header.is_file():
                record = import_record(record_path)
                data = header.read_bytes()
                if record and record.get("header_sha256") == hashlib.sha256(data).hexdigest().upper():
                    if record.get("license_mask") == mask and len(variants) == len(owned):
                        continue
                    if len(data) in (328, 332):
                        # Verified payload; only the licence grows.
                        data = data[:328] + int(mask, 16).to_bytes(4, "little")
                        staged = staging / f"header-{index}"
                        staged.write_bytes(data)
                        staged.replace(header)
                        write_json(record_path, record | dict(
                            sha256=primary, variants=[v["sha256"] for v in variants], license_mask=mask,
                            header_sha256=hashlib.sha256(data).hexdigest().upper()))
                        continue
            extracted = staging / str(index)
            content = extracted / CONTENT / "00000002" / id
            if unpacked:
                # Xenia's installed copy: the same files and header the
                # extractor would publish, verified below like extracted ones.
                shutil.copytree(long_path(unpacked[0]), content)
                staged = extracted / CONTENT / "Headers" / "00000002" / (id + ".header")
                staged.parent.mkdir(parents=True)
                shutil.copyfile(unpacked[1], staged)
            else:
                result = subprocess.run([str(extractor), "--dlc-files", str(input_path),
                                         str(extracted), id], capture_output=True, text=True)
                if result.returncode:
                    raise ValueError(result.stderr.strip() or "DLC extraction failed")
            _, digest = payload_catalog(content)
            if digest != package["payload_sha256"]:
                raise ValueError(f'{package["display_name"]}: extracted content failed verification')
            staged_header = extracted / CONTENT / "Headers" / "00000002" / (id + ".header")
            header_data = staged_header.read_bytes()
            if len(header_data) not in (328, 332) or int.from_bytes(header_data[328:332], "little") != int(
                    combined_mask(variants) if unpacked else variant["license_mask"], 16):
                raise ValueError("content header failed verification")
            header_data = header_data[:328] + int(mask, 16).to_bytes(4, "little")
            staged_header.write_bytes(header_data)
            record = dict(package_id=id, display_name=package["display_name"],
                          sha256=primary, variants=[v["sha256"] for v in variants], payload_sha256=digest,
                          license_mask=mask, file_count=package["file_count"],
                          header_sha256=hashlib.sha256(header_data).hexdigest().upper())
            header.parent.mkdir(parents=True, exist_ok=True)
            disabled.parent.mkdir(parents=True, exist_ok=True)
            # An orphan header/record is recoverable; content becomes visible last.
            staged_header.replace(header)
            write_json(record_path, record)
            if id in repair:
                installed = enabled if enabled.exists() else disabled
                retained = state / "dlc" / "replaced" / id / uuid.uuid4().hex
                retained.parent.mkdir(parents=True, exist_ok=True)
                installed.rename(retained)
                try:
                    content.rename(installed)
                except OSError:
                    retained.rename(installed)
                    raise
            elif not (enabled.exists() or disabled.exists()):
                content.rename(disabled)
    return list_content(state)


def set_enabled(state: Path, id: str, enabled: bool) -> list[dict]:
    state = long_path(state)
    with mutation_lock(state):
        record_path = state / "dlc" / (id + ".json")
        active, inactive, header = package_paths(state, id)
        if not record_path.is_file() or (enabled and not header.is_file()):
            raise ValueError("import the verified package first")
        source, destination = (inactive, active) if enabled else (active, inactive)
        if enabled:
            # Repeated enable must also reject an already active damaged package.
            verified_content(state, id)
        if destination.exists():
            if source.exists():
                raise ValueError("both enabled and disabled copies exist")
            return list_content(state)
        if not source.is_dir():
            raise ValueError("the imported content is missing")
        destination.parent.mkdir(parents=True, exist_ok=True)
        source.rename(destination)
    return list_content(state)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("list", "import", "enable", "disable"))
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--package-id")
    parser.add_argument("--game-root", type=Path, default=ROOT / ".local/game/base")
    parser.add_argument("--extractor", type=Path, default=ROOT / "out/build/win-amd64-release/pinyon_shift_fh1_archive_extract.exe")
    args = parser.parse_args()
    try:
        state = args.state_root.resolve()
        if args.action == "list":
            records = list_content(state)
        elif args.action == "import":
            if args.source is None:
                raise ValueError("choose a DLC input")
            records = import_content(args.source.resolve(), state, args.extractor.resolve())
        else:
            if args.package_id is None:
                raise ValueError("choose an imported package")
            records = set_enabled(state, args.package_id, args.action == "enable")
            if args.action == "enable" and args.package_id == RALLY:
                prepared = subprocess.run([sys.executable, str(ROOT / "tools/prepare-fh1-rally.py"),
                    "--state-root", str(state), "--game-root", str(args.game_root.resolve()),
                    "--extractor", str(args.extractor.resolve())], capture_output=True, text=True)
                if prepared.returncode:
                    raise ValueError("Rally is enabled, but asset preparation failed: " +
                                     (prepared.stderr.strip() or "preparation stopped"))
                records = list_content(state)
        print(json.dumps(dict(packages=records)))
        return 0
    except (OSError, ValueError, zipfile.BadZipFile, subprocess.SubprocessError) as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
