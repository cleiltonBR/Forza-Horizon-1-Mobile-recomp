[CmdletBinding()]
param(
    [ValidateSet('Get', 'Apply', 'Reset', 'Restore')]
    [string]$Action = 'Get',
    # 0 keeps the game's own filtering per texture (anisotropic_override -1).
    [ValidateSet(0, 4, 8, 16)]
    [int]$Anisotropy = 0,
    [ValidateSet('none', 'fxaa', 'fxaa_extreme')]
    [string]$PostEffect = 'none',
    [ValidateSet(1, 2, 3, 4)]
    [int]$ResolutionScale = 1,
    [ValidateSet('vulkan')]
    [string]$GraphicsApi = 'vulkan',
    [ValidateSet('bilinear', 'cas', 'fsr', 'fsr2', 'fsr3', 'dlss')]
    [string]$OutputScaling = 'bilinear',
    [ValidateSet('true', 'false')]
    [string]$TreasureMap = 'true',
    [ValidateSet('custom', 'shipping_1x', 'experimental_2x', 'experimental_3x')]
    [string]$Preset = 'custom',
    # The in-game GRAPHICS PRESET rows (src/ui/settings_menu.cpp); applied
    # after the other choices, which it overrides.
    [ValidateSet('ultra_low_30', 'low_spec_60', 'balanced_40', 'performance_120', 'quality_60')]
    [string]$GamePreset,
    [ValidateSet(0, 30, 60, 120, 240)]
    [int]$PresentationFps = 0,
    [ValidateRange(0, 240)]
    [int]$RenderFps = 60,
    [ValidateSet('true', 'false')]
    [string]$DisableBloom = 'true',
    [ValidateSet('true', 'false')]
    [string]$DisableMotionBlur = 'true',
    [ValidateSet('true', 'false')]
    [string]$DisableDepthOfField = 'true',
    [string]$StateRoot,
    [switch]$Json
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$resolvedStateRoot = if ($StateRoot) {
    [IO.Path]::GetFullPath($StateRoot)
} else {
    Join-Path $repoRoot '.local/preview'
}
$configDirectory = Join-Path $resolvedStateRoot 'config'
$configPath = Join-Path $configDirectory 'pinyon_shift.toml'
$backupDirectory = Join-Path $configDirectory 'backups'
. (Join-Path $PSScriptRoot 'host-config.ps1')

function Get-DefaultConfigText {
    @'
# Pinyon Shift host configuration.
# Schema 29 writes every keyboard bind (#432); schema 28 supports only Vulkan with the split GPU commands thread; schema 26
# stops re-uploading CPU-written memory every frame; schema 25 keeps one
# occlusion-query path; schema 24 retired the renderer choice.
pinyon_shift_config_schema = 29
input_backend = "sdl"
hid_mappings_file = "gamecontrollerdb.txt"
mnk_mode = true
keybind_a = "Space,Return,LMB"
keybind_b = "E,Backspace"
keybind_x = "Q"
keybind_y = "R"
keybind_left_trigger = "S"
keybind_right_trigger = "W"
keybind_left_shoulder = "Z"
keybind_right_shoulder = "C"
keybind_lstick_up = "Up"
keybind_lstick_down = "Down"
keybind_lstick_left = "A,Left"
keybind_lstick_right = "D,Right"
keybind_lstick_press = "F"
keybind_rstick_up = "I"
keybind_rstick_down = "K"
keybind_rstick_left = "J"
keybind_rstick_right = "L"
keybind_rstick_press = "V"
keybind_dpad_up = "Shift+Up"
keybind_dpad_down = "Shift+Down"
keybind_dpad_left = "Shift+Left"
keybind_dpad_right = "Shift+Right"
keybind_back = "Tab,M"
keybind_start = "Escape"
d3d12_allow_variable_refresh_rate_and_tearing = false
gpu_backend = "vulkan"
gpu_record_thread = true
vsync = true
host_present_fps_limit = 0
host_present_sleep_spin = true
pinyon_shift_stabilize_vehicle_presentation = false
pinyon_shift_skip_opening_movies = false
pinyon_shift_fh1_render_fps_limit = 60
pinyon_shift_fh1_source_presentation = true
xma_relaxed_padding_admission = false
anisotropic_override = -1
present_effect = "bilinear"
swap_post_effect = "none"
disable_bloom = true
disable_motion_blur = true
disable_depth_of_field = true
fh1_msaa_single_sample = true
draw_resolution_scale_x = 1
draw_resolution_scale_y = 1
clear_memory_page_state = false
'@
}

# Settings a config file may still carry from an earlier release. Apply writes
# the current schema, so the game's own migration never sees the file again:
# drop every setting that migration retires (src/pinyon_shift_app.cpp).
# The keys configurations had through schema 28; schema 29 writes them into
# older files that lack them, as the game does (src/config/default_keys.h).
$schema28Keys = [ordered]@{
    'keybind_a' = 'LMB,Space'
    'keybind_b' = 'Quote,Backspace'
    'keybind_x' = 'L'
    'keybind_y' = 'P'
    'keybind_left_trigger' = 'Q,I'
    'keybind_right_trigger' = 'E,O'
    'keybind_left_shoulder' = '1'
    'keybind_right_shoulder' = '3'
    'keybind_lstick_up' = 'W'
    'keybind_lstick_down' = 'S'
    'keybind_lstick_left' = 'A'
    'keybind_lstick_right' = 'D'
    'keybind_lstick_press' = 'F'
    'keybind_rstick_up' = 'Up'
    'keybind_rstick_down' = 'Down'
    'keybind_rstick_left' = 'Left'
    'keybind_rstick_right' = 'Right'
    'keybind_rstick_press' = 'K'
    'keybind_dpad_up' = 'Shift+Up'
    'keybind_dpad_down' = 'Shift+Down'
    'keybind_dpad_left' = 'Shift+Left'
    'keybind_dpad_right' = 'Shift+Right'
    'keybind_back' = 'Z,Tab'
    'keybind_start' = 'Return'
}

$retiredSettings = @(
    'pinyon_shift_fh1_guest_vblank_hz',
    'pinyon_shift_native_renderer_texture_bridge',
    'pinyon_shift_native_renderer',
    'pinyon_shift_native_renderer_sky_horizon_suppression',
    'pinyon_shift_native_renderer_census',
    'pinyon_shift_fh1_native_v4',
    'readback_resolve_half_pixel_offset',
    'readback_memexport',
    'readback_memexport_fast',
    'fh1_renderer',
    'fh1_native_shadow',
    'fh1_native_shadow_dump_dir',
    'fh1_native_shadow_dump_frames',
    'fh1_native_shadow_verify',
    'fh1_native_shadow_verify_draws',
    'fh1_discovery_sampling',
    'fh1_owned_depth_clear',
    'fh1_owned_depth_tile_clear',
    'fh1_native_reflection_mips',
    'fh1_mip_decode_probe',
    'fh1_native_ui_boundary_probe',
    'fh1_glow_probe',
    'fh1_recycle_geometry_buffers',
    'fh1_contain_geometry_windows',
    'fh1_cache_geometry_rejections',
    'fh1_geometry_cache_mb',
    'native_stencil_value_output',
    'native_stencil_value_output_d3d12_intel',
    'pinyon_shift_native_race',
    'pinyon_shift_native_race_capture_start_frame',
    'pinyon_shift_native_ui_live',
    'pinyon_shift_native_ui_replay_source_frame',
    'pinyon_shift_native_ui_scene_probe',
    'pinyon_shift_native_ui_shadow_start_frame',
    'pinyon_shift_native_ui_clear_probe',
    'pinyon_shift_native_output_clear_probe',
    'pinyon_shift_native_scene_clear_probe',
    'pinyon_shift_native_scene_triangle_probe',
    'pinyon_shift_native_small_target_probe',
    'pinyon_shift_native_track_probe',
    'pinyon_shift_native_ordered_live_probe',
    'pinyon_shift_fh1_clear_producer_trace',
    'pinyon_shift_fh1_scene_dump',
    'pinyon_shift_snr01_trace_following_frame',
    'pinyon_shift_snr01_trace_resident_packet_writers',
    'pinyon_shift_snr01_trace_source_frame',
    'pinyon_shift_snr01_watch_packet_pages',
    'pinyon_shift_snr02_item_payload_probe',
    'pinyon_shift_snr02_trace_first_rebuild_after_frame',
    'pinyon_shift_snr02_trace_view_call',
    'pinyon_shift_snr02_track_payload_probe',
    'pinyon_shift_snr03_probe_following_frame',
    'pinyon_shift_snr03_probe_frame',
    'pinyon_shift_snr04_live_continuous',
    'pinyon_shift_snr04_live_handoff',
    'pinyon_shift_snr04_live_source_frame',
    'pinyon_shift_snr04_live_worker',
    'pinyon_shift_snr_m02_trace_source_frame',
    'occlusion_query',
    'zpd_end_policy',
    'zpd_end_fallback'
)

# The values of each in-game preset, as its row in the settings screen sets
# them (Vulkan and the recorder thread are always set by Apply).
# Every preset sets shadows, the reflection rate and single-pass scene
# back to the desktop defaults that ULTRA LOW 30 turns down, as the game does.
$gamePresets = [ordered]@{
    ultra_low_30 = [ordered]@{ draw_resolution_scale_x = '1'; draw_resolution_scale_y = '1'
        present_effect = '"bilinear"'; fh1_msaa_single_sample = 'true'; host_present_fps_limit = '0'
        pinyon_shift_fh1_render_fps_limit = '30'; anisotropic_override = '-1'; swap_post_effect = '"none"'
        pinyon_shift_fh1_shadows = 'false'; pinyon_shift_fh1_env_map_rate = '0.25'
        fh1_untile_predicated_tiling = 'true' }
    low_spec_60 = [ordered]@{ draw_resolution_scale_x = '1'; draw_resolution_scale_y = '1'
        present_effect = '"bilinear"'; fh1_msaa_single_sample = 'true'; host_present_fps_limit = '0'
        pinyon_shift_fh1_render_fps_limit = '60'; anisotropic_override = '-1'; swap_post_effect = '"none"'
        pinyon_shift_fh1_shadows = 'true'; pinyon_shift_fh1_env_map_rate = '1'
        fh1_untile_predicated_tiling = 'false' }
    balanced_40 = [ordered]@{ draw_resolution_scale_x = '1'; draw_resolution_scale_y = '1'
        present_effect = '"bilinear"'; fh1_msaa_single_sample = 'true'; host_present_fps_limit = '0'
        pinyon_shift_fh1_render_fps_limit = '40'; anisotropic_override = '-1'; swap_post_effect = '"none"'
        pinyon_shift_fh1_shadows = 'true'; pinyon_shift_fh1_env_map_rate = '1'
        fh1_untile_predicated_tiling = 'false' }
    performance_120 = [ordered]@{ draw_resolution_scale_x = '1'; draw_resolution_scale_y = '1'
        present_effect = '"fsr"'; fh1_msaa_single_sample = 'true'; host_present_fps_limit = '0'
        pinyon_shift_fh1_render_fps_limit = '120'
        pinyon_shift_fh1_shadows = 'true'; pinyon_shift_fh1_env_map_rate = '1'
        fh1_untile_predicated_tiling = 'false' }
    quality_60 = [ordered]@{ draw_resolution_scale_x = '2'; draw_resolution_scale_y = '2'
        present_effect = '"bilinear"'; fh1_msaa_single_sample = 'false'; host_present_fps_limit = '0'
        pinyon_shift_fh1_render_fps_limit = '60'
        pinyon_shift_fh1_shadows = 'true'; pinyon_shift_fh1_env_map_rate = '1'
        fh1_untile_predicated_tiling = 'false' }
}

# The in-game preset the file matches, as the settings screen shows it.
function Get-GamePreset([string]$Text) {
    $defaults = @{ present_effect = '"bilinear"'; fh1_msaa_single_sample = 'false'
        host_present_fps_limit = '0'; anisotropic_override = '-1'; swap_post_effect = '"none"'
        pinyon_shift_fh1_render_fps_limit = '0'; draw_resolution_scale_x = '1'; draw_resolution_scale_y = '1'
        pinyon_shift_fh1_shadows = 'true'; pinyon_shift_fh1_env_map_rate = '1'; fh1_untile_predicated_tiling = 'false' }
    foreach ($name in $gamePresets.Keys) {
        $all = $true
        foreach ($setting in $gamePresets[$name].GetEnumerator()) {
            $value = (Get-TomlValue $Text $setting.Key $defaults[$setting.Key]).Trim('"').ToLowerInvariant()
            if ($value -ne $setting.Value.Trim('"').ToLowerInvariant()) { $all = $false; break }
        }
        if ($all) { return $name }
    }
    'custom'
}

function Get-SchemaVersion([string]$Text) {
    $match = [regex]::Match($Text,
        '(?m)^\s*pinyon_shift_config_schema\s*=\s*(?<value>[0-9]+)\s*(?:#.*)?$')
    # A file without one was saved by the old F4 overlay with only changed
    # settings; the game keeps them under the current schema, so do the same.
    if (-not $match.Success) { return 29 }
    [int]$match.Groups['value'].Value
}

function Get-SettingsResult([string]$Text, [string]$BackupPath, [string]$Operation) {
    $override = [int](Get-TomlValue $Text 'anisotropic_override' '-1')
    $anisotropyValue = switch ($override) { 3 { 4 } 4 { 8 } 5 { 16 } default { 0 } }
    $resolutionScale = [int](Get-TomlValue $Text 'draw_resolution_scale_x' '1')
    $clearPageState = (Get-TomlValue $Text 'clear_memory_page_state' 'false') -eq 'true'
    $vsyncEnabled = (Get-TomlValue $Text 'vsync' 'true') -eq 'true'
    $presentationFps = [int](Get-TomlValue $Text 'host_present_fps_limit' '0')
    $renderFps = [int](Get-TomlValue $Text 'pinyon_shift_fh1_render_fps_limit' '0')
    # Player settings use Vulkan; schema 28 migrates legacy backend selections.
    $graphicsApi = 'vulkan'
    $presetName = if ($resolutionScale -eq 2) {
        'experimental_2x'
    } elseif ($resolutionScale -eq 3) {
        'experimental_3x'
    } elseif ($resolutionScale -eq 1 -and $vsyncEnabled) {
        'shipping_1x'
    } else {
        'custom'
    }
    [ordered]@{
        schema = 'pinyon-shift.graphics-settings.v2'
        operation = $Operation.ToLowerInvariant()
        config_path = $configPath
        backup_path = $BackupPath
        settings = [ordered]@{
            anisotropy = $anisotropyValue
            post_effect = Get-TomlValue $Text 'swap_post_effect' 'none'
            disable_bloom = (Get-TomlValue $Text 'disable_bloom' 'true') -eq 'true'
            disable_motion_blur = (Get-TomlValue $Text 'disable_motion_blur' 'true') -eq 'true'
            disable_depth_of_field = (Get-TomlValue $Text 'disable_depth_of_field' 'true') -eq 'true'
            preset = $presetName
            game_preset = Get-GamePreset $Text
            resolution_scale = $resolutionScale
            graphics_api = $graphicsApi
            output_scaling = (Get-TomlValue $Text 'present_effect' '"bilinear"').Trim('"').ToLowerInvariant()
            # Where the image lands, for the launcher's resolution line.
            fullscreen = (Get-TomlValue $Text 'fullscreen' 'true') -eq 'true'
            monitor = [int](Get-TomlValue $Text 'monitor' '0')
            window_width = [int](Get-TomlValue $Text 'window_width' '0')
            window_height = [int](Get-TomlValue $Text 'window_height' '0')
            letterbox = (Get-TomlValue $Text 'present_letterbox' 'true') -eq 'true'
            # The game turns the Treasure Map on unless the file says false.
            treasure_map = (Get-TomlValue $Text 'pinyon_shift_dlc_treasure_map' 'true') -eq 'true'
            clear_memory_page_state = $clearPageState
            vsync = $vsyncEnabled
            host_present_fps_limit = $presentationFps
            fh1_render_fps_limit = $renderFps
            host_present_sleep_spin =
                (Get-TomlValue $Text 'host_present_sleep_spin' 'true') -eq 'true'
        }
        restart_required = $Operation -ne 'Get'
    }
}

[void](New-Item -ItemType Directory -Force -Path $configDirectory)
$backup = $null
switch ($Action) {
    'Get' {
        $text = if (Test-Path -LiteralPath $configPath -PathType Leaf) {
            Get-Content -LiteralPath $configPath -Raw
        } else { Get-DefaultConfigText }
        $schema = Get-SchemaVersion $text
        if ($schema -lt 1 -or $schema -gt 29) { throw "Unsupported host configuration schema: $schema" }
    }
    'Reset' {
        $backup = New-HostConfigBackup $configPath
        $text = Get-DefaultConfigText
        Write-HostConfig $configPath $text
    }
    'Restore' {
        if (-not (Test-Path -LiteralPath $backupDirectory -PathType Container)) {
            throw 'No runtime-settings backup is available.'
        }
        $source = Get-ChildItem -LiteralPath $backupDirectory -Filter 'pinyon_shift-*.toml' -File |
            Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
        if ($null -eq $source) { throw 'No runtime-settings backup is available.' }
        $backup = New-HostConfigBackup $configPath
        $text = Get-Content -LiteralPath $source.FullName -Raw
        $schema = Get-SchemaVersion $text
        if ($schema -lt 1 -or $schema -gt 29) { throw "Backup uses unsupported schema: $schema" }
        Write-HostConfig $configPath $text
    }
    'Apply' {
        $text = if (Test-Path -LiteralPath $configPath -PathType Leaf) {
            Get-Content -LiteralPath $configPath -Raw
        } else { Get-DefaultConfigText }
        $schema = Get-SchemaVersion $text
        if ($schema -lt 1 -or $schema -gt 29) { throw "Unsupported host configuration schema: $schema" }
        $backup = New-HostConfigBackup $configPath
        # The retired guest vblank rate became the render limit, which now
        # defaults to 60 (LOW-SPEC 60), not the display's rate.
        $hadLegacyVblank = [regex]::IsMatch($text, '(?m)^[ \t]*pinyon_shift_fh1_guest_vblank_hz[ \t]*=')
        foreach ($retired in $retiredSettings) {
            $text = Remove-TomlValue $text $retired
        }
        # readback_resolve is a developer setting; only launchers before
        # schema 24 wrote it for players (src/pinyon_shift_app.cpp).
        if ($schema -lt 24) { $text = Remove-TomlValue $text 'readback_resolve' }
        # Schema 26 turned clear_memory_page_state off (src/pinyon_shift_app.cpp).
        if ($schema -lt 26) { $text = Set-TomlValue $text 'clear_memory_page_state' 'false' }
        # Schema 28 makes Vulkan the only supported player backend.
        $text = Set-TomlValue $text 'gpu_backend' '"vulkan"'
        $text = Set-TomlValue $text 'gpu_record_thread' 'true'
        # Schema 28 turns off depth of field once, as the game does
        # (src/pinyon_shift_app.cpp); a choice passed below still wins.
        if ($schema -lt 28) { $text = Set-TomlValue $text 'disable_depth_of_field' 'true' }
        if ($schema -lt 29) {
            foreach ($key in $schema28Keys.Keys) {
                if (-not [regex]::IsMatch($text, "(?m)^[ \t]*$key[ \t]*=")) {
                    $text = Set-TomlValue $text $key ('"' + $schema28Keys[$key] + '"')
                }
            }
        }
        $text = Set-TomlValue $text 'pinyon_shift_config_schema' '29'
        $text = Set-TomlValue $text 'pinyon_shift_fh1_source_presentation' 'true'
        if (-not [regex]::IsMatch($text, '(?m)^[ \t]*xma_relaxed_padding_admission[ \t]*=')) {
            $text = Set-TomlValue $text 'xma_relaxed_padding_admission' 'false'
        }
        # Only the settings passed are written: the in-game settings screen
        # edits the same file, and saving here must not undo its choices.
        $bound = $PSBoundParameters
        $effectiveResolution = switch ($Preset) {
            'shipping_1x' { 1 }
            'experimental_2x' { 2 }
            'experimental_3x' { 3 }
            default { $null }
        }
        if ($null -eq $effectiveResolution -and $bound.ContainsKey('ResolutionScale')) {
            $effectiveResolution = $ResolutionScale
        }
        if ($null -ne $effectiveResolution) {
            $text = Set-TomlValue $text 'draw_resolution_scale_x' ([string]$effectiveResolution)
            $text = Set-TomlValue $text 'draw_resolution_scale_y' ([string]$effectiveResolution)
        }
        if ($bound.ContainsKey('TreasureMap')) {
            $text = Set-TomlValue $text 'pinyon_shift_dlc_treasure_map' $TreasureMap
        }
        if ($bound.ContainsKey('OutputScaling')) {
            $text = Set-TomlValue $text 'present_effect' ('"' + $OutputScaling + '"')
        }
        if ($bound.ContainsKey('Anisotropy')) {
            $override = switch ($Anisotropy) { 0 { -1 } 4 { 3 } 8 { 4 } 16 { 5 } }
            $text = Set-TomlValue $text 'anisotropic_override' ([string]$override)
        }
        if ($bound.ContainsKey('PostEffect')) {
            $text = Set-TomlValue $text 'swap_post_effect' ('"' + $PostEffect + '"')
        }
        if ($bound.ContainsKey('DisableBloom')) {
            $text = Set-TomlValue $text 'disable_bloom' $DisableBloom
        }
        if ($bound.ContainsKey('DisableMotionBlur')) {
            $text = Set-TomlValue $text 'disable_motion_blur' $DisableMotionBlur
        }
        if ($bound.ContainsKey('DisableDepthOfField')) {
            $text = Set-TomlValue $text 'disable_depth_of_field' $DisableDepthOfField
        }
        if ($bound.ContainsKey('PresentationFps')) {
            $text = Set-TomlValue $text 'host_present_fps_limit' ([string]$PresentationFps)
        }
        if ($bound.ContainsKey('RenderFps') -or $hadLegacyVblank) {
            $text = Set-TomlValue $text 'pinyon_shift_fh1_render_fps_limit' ([string]$RenderFps)
        }
        if ($GamePreset) {
            foreach ($setting in $gamePresets[$GamePreset].GetEnumerator()) {
                $text = Set-TomlValue $text $setting.Key $setting.Value
            }
        }
        $text = Set-TomlValue $text 'host_present_sleep_spin' 'true'
        Write-HostConfig $configPath $text
    }
}

$result = Get-SettingsResult $text $backup $Action
if ($Json) { $result | ConvertTo-Json -Depth 5 -Compress } else { [pscustomobject]$result }
